﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MvcCascade.Models
{
    public class FindingsViewModel
    {
        [Required]
        [Display(Name = "Unit")]
        public int? UnitId { get; set; }

        [Required]
        [Display(Name = "Exception")]
        public int? ExceptionId { get; set; }
        public string? UnitDesc { get; set; }

        // Populated in the GET; used to build <option> items
        public IEnumerable<SelectListItem> Units { get; set; } = new List<SelectListItem>();
        public IEnumerable<SelectListItem> Exceptions { get; set; } = new List<SelectListItem>();
    }
}
