﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcCascade.Data;
using MvcCascade.Models;
using System;
using System.Diagnostics.Metrics;
using System.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace MvcCascade.Controllers
{
    [AutoValidateAntiforgeryToken] // applies to unsafe HTTP verbs by default (POST/PUT/DELETE)
    public class FindingsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public sealed record ExceptionDto(int Id, string Name);

        public FindingsController(ApplicationDbContext context)
        {
            _context = context;
        }
        // Example sketch if you have DbContext with Countries and Cities
        [HttpGet]
        public async Task<IActionResult> Index(int? preselectUnitId = null, int? preselectExceptionId = null, string? q = null)
        {
            var vm = new FindingsViewModel();

            var units = await _context.Unit
                .OrderBy(c => c.Name)
                .Select(c => new { c.Id, c.Name })
                .ToListAsync();

            vm.Units = units.Select(c => new SelectListItem
            {
                Value = c.Id.ToString(),
                Text = c.Name,
                Selected = (preselectUnitId == c.Id)
            });
           

            if (preselectUnitId.HasValue)
            {
                var exceptions = await _context.Exception
                    .Where(x => x.Id == preselectUnitId)
                    .OrderBy(x => x.Name)
                    .Select(x => new { x.Id, x.Name })
                    .ToListAsync();

                vm.Exceptions = exceptions.Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Name,
                    Selected = (preselectExceptionId == x.Id)
                });
            }
            else
            {
                /*
                var exceptions = await _context.Exception
                  .Where(x => x.Id == preselectUnitId)
                  .OrderBy(x => x.Name)
                  .Select(x => new { x.Id, x.Name })
                  .ToListAsync();
                //Set to 0 
                vm.Exceptions = exceptions.Select(x => new SelectListItem
                {
                    Value = "0",  //x.Id.ToString(),
                    Text = x.Name,
                    Selected = (preselectExceptionId == x.Id)
                });
                */
                vm.Exceptions = Enumerable.Empty<SelectListItem>();
                
            }


            
            return View(vm);
        }


        // POST: /Customers/SearchJson
        [HttpPost]
        public async Task<IActionResult> SearchJson([FromBody] SearchRequest payload)
        {
          var q = payload?.Q?.Trim();

            if (string.IsNullOrWhiteSpace(q))
            {
                return Json(new
                {
                    success = true,
                    message = "No query provided.",
                    data = (object?)null
                });
            }

            // Example logic: exact by Code/Email, contains by Name; only Active
            var branches = await _context.Branches 
                .AsNoTracking()
                .Where(c => c.BRCODE  == q || c.BRNAME == q || EF.Functions.Like(c.BRNAME , $"%{q}%"))
                .OrderBy(c => c.BRNAME)
                .Select(c => new BranchesDto
                {
                    Id = c.Id,
                    BranchCode  = c.BRCODE,
                    BranchName = c.BRNAME,
                    BranchAcro = c.BRACRO,
                    BranchArea  = c.AREA,
                    BranchRegion = c.REGION
                })
                .FirstOrDefaultAsync();

            if (branches == null)
            {
                // 200 with success=false is fine for UI workflows; alternatively return NotFound.
                return Json(new
                {
                    success = false,
                    message = "No matching record found.",
                    data = (object?)null
                });
            }

            return Json(new
            {
                success = true,
                message = (string?)null,
                data = branches 
            });
        }

        // DTOs / payloads
        public class SearchRequest
        {
            public string? Q { get; set; }
        }

        public class BranchesDto
        {
            public int Id { get; set; }
            public string BranchCode { get; set; } = default!;
            public string BranchName { get; set; } = default!;
            public string BranchAcro { get; set; } = default!;
            public string BranchArea { get; set; } = default!;
            public string BranchRegion { get; set; } = default!;
        }

        // JSON endpoint: returns cities for a country
        [HttpGet]
        public async Task<IActionResult> GetExceptions(int unitId)
        {

            if(unitId <= 0)
            return Json(Array.Empty<object>());

            var exceptions = await _context.Exception
                .AsNoTracking()
                .Where(c => c.Id == unitId)
                .OrderBy(c => c.Name)
                .Select(c => new { value = c.Id, text = c.Name })
                .ToListAsync();

            return Json(exceptions); // MVC JSON return

        }

 
        // GET: /Cities/GetCountryInfo?countryId=1
        [HttpGet]
        public async Task<IActionResult> GetUnitDesc(int unitId)
        {
            if (unitId <= 0)
                return BadRequest("Invalid countryId");

            // Load country with required fields
            var unit = await _context.Unit
                .Where(c => c.Id == unitId)
                .Select(c => new
                {
                    id = c.Id,
                    name = c.Name,
                    desc = c.Desc
                })
                .FirstOrDefaultAsync();

            if (unit == null)
                return Json(new { country = (object?)null }); //, cities = Array.Empty<object>() });

            // Load related cities
            /*
            var cities = await _db.Cities
                .Where(c => c.CountryId == countryId)
                .OrderBy(c => c.Name)
                .Select(c => new { value = c.Id, text = c.Name })
                .ToListAsync();
            */

            return Json(new
            {
                unit //exception
            });
        }





        // Regular or AJAX submit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Submit(FindingsViewModel model)
        {
            if (!ModelState.IsValid)
            {

                // Rebuild the lists for redisplay    

                var units = _context.Unit
                    .OrderBy(c => c.Name)
                    .Select(c => new { c.Id, c.Name })
                    .ToListAsync();

                model.Units = _context.Unit.Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name, Selected = (model.UnitId == c.Id) });

                var CitiesByCountry =  _context.Exception
                       .Where(x => x.Id == model.UnitId)
                       .OrderBy(x => x.Name)
                       .Select(x => new { x.Id, x.Name })
                       .ToListAsync();               

                if ((model.UnitId.HasValue) && (CitiesByCountry != null))
                {
                    model.Exceptions = _context.Exception.Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name, Selected = (model.ExceptionId == c.Id) });
                }
                else
                {
                    model.Exceptions = Enumerable.Empty<SelectListItem>();
                }

                // If request expects JSON (AJAX), send errors
                if (Request.Headers["Accept"].ToString().Contains("application/json", StringComparison.OrdinalIgnoreCase))
                {
                    var errors = ModelState
                        .Where(kvp => kvp.Value!.Errors.Count > 0)
                        .ToDictionary(
                            kvp => kvp.Key,
                            kvp => kvp.Value!.Errors.Select(e => e.ErrorMessage).ToArray()
                        );
                    return BadRequest(new { message = "Validation failed.", errors });
                }

                // Non-AJAX fallback
                return View("Index", model);
            }

            // TODO: persist data here (CountryId, CityId)

            // AJAX success
            if (Request.Headers["Accept"].ToString().Contains("application/json", StringComparison.OrdinalIgnoreCase))
            {
                return Ok(new { message = "Saved successfully.", redirectUrl = Url.Action(nameof(Success)) });
            }

            // PRG for non-AJAX
            TempData["Success"] = "Saved successfully.";
            return RedirectToAction(nameof(Success));
        }

        [HttpGet]
        public IActionResult Success()
        {
            ViewBag.Message = TempData["Success"] ?? "Saved.";
            return View();
        }

    }
}
 