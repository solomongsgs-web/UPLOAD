﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;


namespace MvcCascade.Models
{
    public class Branches
    {
        public int Id { get; set; }
        [Display(Name = "Type")]
        public string? TYPE { get; set; }
        [Display(Name = "Branch Acro")]
        public string? BRACRO { get; set; }
        [Display(Name = "Branch Code")]
        public string? BRCODE { get; set; }
        [Display(Name = "Branch Name")]
        public string? BRNAME { get; set; }


        [Display(Name = "Area")]
        public string? AREA { get; set; }
        [Display(Name = "Region")]
        public string? REGION { get; set; }
        [Display(Name = "Region Name")]
        public string? RGNAME { get; set; }
        [Display(Name = "New BRSTN")]
        public string? NEWBRSTN { get; set; }

        [Display(Name = "Old BRSTN")]
        public string? OLDBRSTN { get; set; }
        [Display(Name = "Old Branch Name")]
        public string? OLDNAME { get; set; }
        [Display(Name = "Email")]
        public string? Email { get; set; }
        [Display(Name = "ORDER")]
        public int? ORDERING { get; set; }

    }
}
