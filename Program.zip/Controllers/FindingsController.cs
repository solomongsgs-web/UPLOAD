﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcCascade.Data;
using MvcCascade.Models;
using System;
using System.Diagnostics.Metrics;
using System.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace MvcCascade.Controllers
{
    public class FindingsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public sealed record ExceptionDto(int Id, string Name);

        public FindingsController(ApplicationDbContext context)
        {
            _context = context;
        }
        // Example sketch if you have DbContext with Countries and Cities
        public async Task<IActionResult> Index(int? preselectUnitId = null, int? preselectExceptionId = null)
        {
            var vm = new FindingsViewModel();

            var units = await _context.Unit
                .OrderBy(c => c.Name)
                .Select(c => new { c.Id, c.Name })
                .ToListAsync();

            vm.Units = units.Select(c => new SelectListItem
            {
                Value = c.Id.ToString(),
                Text = c.Name,
                Selected = (preselectUnitId == c.Id)
            });
           

            if (preselectUnitId.HasValue)
            {
                var exceptions = await _context.Exception
                    .Where(x => x.Id == preselectUnitId)
                    .OrderBy(x => x.Name)
                    .Select(x => new { x.Id, x.Name })
                    .ToListAsync();

                vm.Exceptions = exceptions.Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Name,
                    Selected = (preselectExceptionId == x.Id)
                });
            }
            else
            {
                /*
                var exceptions = await _context.Exception
                  .Where(x => x.Id == preselectUnitId)
                  .OrderBy(x => x.Name)
                  .Select(x => new { x.Id, x.Name })
                  .ToListAsync();
                //Set to 0 
                vm.Exceptions = exceptions.Select(x => new SelectListItem
                {
                    Value = "0",  //x.Id.ToString(),
                    Text = x.Name,
                    Selected = (preselectExceptionId == x.Id)
                });
                */
                vm.Exceptions = Enumerable.Empty<SelectListItem>();
                
            }

            return View(vm);
        }




        // JSON endpoint: returns cities for a country
        [HttpGet]
        public async Task<IActionResult> GetExceptions(int unitId)
        {

            if(unitId <= 0)
            return Json(Array.Empty<object>());

            var exceptions = await _context.Exception
                .AsNoTracking()
                .Where(c => c.Id == unitId)
                .OrderBy(c => c.Name)
                .Select(c => new { value = c.Id, text = c.Name })
                .ToListAsync();

            return Json(exceptions); // MVC JSON return

        }

 
        // GET: /Cities/GetCountryInfo?countryId=1
        [HttpGet]
        public async Task<IActionResult> GetUnitDesc(int unitId)
        {
            if (unitId <= 0)
                return BadRequest("Invalid countryId");

            // Load country with required fields
            var unit = await _context.Unit
                .Where(c => c.Id == unitId)
                .Select(c => new
                {
                    id = c.Id,
                    name = c.Name,
                    desc = c.Desc
                })
                .FirstOrDefaultAsync();

            if (unit == null)
                return Json(new { country = (object?)null }); //, cities = Array.Empty<object>() });

            // Load related cities
            /*
            var cities = await _db.Cities
                .Where(c => c.CountryId == countryId)
                .OrderBy(c => c.Name)
                .Select(c => new { value = c.Id, text = c.Name })
                .ToListAsync();
            */

            return Json(new
            {
                unit //exception
            });
        }





        // Regular or AJAX submit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Submit(FindingsViewModel model)
        {
            if (!ModelState.IsValid)
            {
                Dictionary<int, List<(int Id, string Name)>> CitiesByCountry = new();

                // Rebuild the lists for redisplay
                model.Units = _context.Unit.Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name, Selected = (model.UnitId == c.Id) });
            
                if (model.UnitId.HasValue && CitiesByCountry.TryGetValue(model.UnitId.Value, out var exceptions))
                {
                    model.Exceptions = exceptions.Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name, Selected = (model.ExceptionId == c.Id) });
                }
                else
                {
                    model.Exceptions = Enumerable.Empty<SelectListItem>();
                }

                // If request expects JSON (AJAX), send errors
                if (Request.Headers["Accept"].ToString().Contains("application/json", StringComparison.OrdinalIgnoreCase))
                {
                    var errors = ModelState
                        .Where(kvp => kvp.Value!.Errors.Count > 0)
                        .ToDictionary(
                            kvp => kvp.Key,
                            kvp => kvp.Value!.Errors.Select(e => e.ErrorMessage).ToArray()
                        );
                    return BadRequest(new { message = "Validation failed.", errors });
                }

                // Non-AJAX fallback
                return View("Index", model);
            }

            // TODO: persist data here (CountryId, CityId)

            // AJAX success
            if (Request.Headers["Accept"].ToString().Contains("application/json", StringComparison.OrdinalIgnoreCase))
            {
                return Ok(new { message = "Saved successfully.", redirectUrl = Url.Action(nameof(Success)) });
            }

            // PRG for non-AJAX
            TempData["Success"] = "Saved successfully.";
            return RedirectToAction(nameof(Success));
        }

        [HttpGet]
        public IActionResult Success()
        {
            ViewBag.Message = TempData["Success"] ?? "Saved.";
            return View();
        }

    }
}
 