﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MvcCascade.Models
{
    public class FindingsViewModel
    {
        [Required]
        [Display(Name = "Unit")]
        public int? UnitId { get; set; }

        [Required]
        [Display(Name = "Exception")]
        public int? ExceptionId { get; set; }
        [Required]
        public string? UnitDesc { get; set; }
        [Required]
        public string? BranchCode { get; set; }
        [Required]
        public string? BranchName { get; set; }
        [Required]
        public string? BranchAcro {  get; set; }
        [Required]
        public string? BranchArea {  get; set; }
        [Required]
        public string? BranchRegion { get; set; }
        [Required]
        public string? ExDate { get; set; }
        [Required]
        public string? Others {  get; set; }
        [Required]
        public string? Remarks { get; set; }
        [Required]
        public int? Count { get; set; } = 0;
        [Required]
        public string? Status { get; set; }
        // Populated in the GET; used to build <option> items
        public IEnumerable<SelectListItem> Units { get; set; } = new List<SelectListItem>();
        public IEnumerable<SelectListItem> Exceptions { get; set; } = new List<SelectListItem>();
    }
}
