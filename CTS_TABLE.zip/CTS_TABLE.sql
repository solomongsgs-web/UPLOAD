USE [CTS_WEB]
GO

/****** Object:  Table [dbo].[Unit]    Script Date: 17/03/2026 4:29:58 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Unit](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NULL,
	[Desc] [nvarchar](50) NULL
) ON [PRIMARY]

GO

USE [CTS_WEB]
GO

/****** Object:  Table [dbo].[Exception]    Script Date: 17/03/2026 4:30:07 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Exception](
	[IdCtr] [int] IDENTITY(1,1) NOT NULL,
	[Id] [int] NOT NULL,
	[Name] [nvarchar](max) NULL,
	[UnitAcro] [nvarchar](50) NULL,
	[EID] [nvarchar](8) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO



