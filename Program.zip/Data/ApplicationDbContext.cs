﻿using Microsoft.EntityFrameworkCore;
using MvcCascade.Data;
using MvcCascade.Models;
using System.Diagnostics.Metrics;
using Exception = MvcCascade.Models.Exception;


namespace MvcCascade.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        { }

        public DbSet<Unit> Unit { get; set; }
        public DbSet<Exception> Exception { get; set; }
  
    }
}
 