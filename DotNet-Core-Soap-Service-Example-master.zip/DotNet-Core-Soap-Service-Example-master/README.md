# DotNet-Core-Soap-Service-Example
Soap Web Services using .Net Core. 

You can also find Step by Step Tutorial here => https://dottutorials.net/creating-soap-web-services-dot-net-core-tutorial/
