﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.Metrics;

namespace MvcCascade.Models
{
    public class Exception
    {
        public int IdCtr { get; set; }

        [Required]
        public int Id { get; set; }

        
        [MaxLength(100)]
        public string Name { get; set; }

        [MaxLength(4)]
        public string UnitAcro { get; set; }
 
        [MaxLength(10)]
        public string EID { get; set; }


    }
}
