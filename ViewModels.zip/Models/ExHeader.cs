﻿

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MvcCascade.Models
{
    public class ExHeader
    {
        public int Id { get; set; }

        [Required]
        public DateTime RDATE { get; set; } = DateTime.Today;

        [Required, StringLength(20)]
        public string UNIT { get; set; }  

        [Required, StringLength(12)]
        public string PKEY { get; set; } = default!;

        [Required, StringLength(20)]
        public string REGION { get; set; } = default!;

        [Required, StringLength(20)]
        public string AREA { get; set; } = default!;
        [Required, StringLength(4)]
        public string ACRO { get; set; } = default!;

        [Required, StringLength(10)]
        public string BRCODE { get; set; } = default!;
        [Required, StringLength(80)]
        public string BRNAME { get; set; } = default!;
        public int ORD { get; set; }
        public int TOTAL { get; set; }
        [Required, StringLength(4)]
        public string TYPE { get; set; } = default!;
        public ICollection<ExDetail> ExDetails { get; set; } = new List<ExDetail>();

    }
}
 