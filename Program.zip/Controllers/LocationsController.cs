﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MvcCascade.Models;
using System;

namespace MvcCascade.Controllers
{
    public class LocationsController : Controller
    {
        // Simulated in-memory data store
        private static readonly List<(int Id, string Name)> Countries = new()
        {
            (1, "Philippines"),
            (2, "United States"),
            (3, "Japan")
        };

        private static readonly Dictionary<int, List<(int Id, string Name)>> CitiesByCountry = new()
        {
            [1] = new() { (101, "Makati"), (102, "Quezon City"), (103, "Cebu City") },
            [2] = new() { (201, "New York"), (202, "Seattle"), (203, "Austin") },
            [3] = new() { (301, "Tokyo"), (302, "Osaka"), (303, "Kyoto") }
        };


        [HttpGet]
        public IActionResult Index(int? preselectCountryId = null, int? preselectCityId = null)
        {
            var vm = new AddressViewModel
            {
                Countries = Countries
                    .Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name, Selected = (preselectCountryId == c.Id) })
                    .ToList()
            };

            // If preselected country is provided, pre-load its cities; otherwise empty
            if (preselectCountryId.HasValue && CitiesByCountry.TryGetValue(preselectCountryId.Value, out var cities))
            {
                vm.Cities = cities
                    .Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name, Selected = (preselectCityId == c.Id) })
                    .ToList();
            }
            else
            {
                vm.Cities = Enumerable.Empty<SelectListItem>();
            }

            return View(vm);

        }





 
        // JSON endpoint: returns cities for a country
        [HttpGet]
        public IActionResult GetCities(int countryId)
        {
            if (!CitiesByCountry.TryGetValue(countryId, out var cities))
            {
                // Return 404 or empty list; here we return empty list with 200
                return Json(Array.Empty<object>());
            }

            // Return minimal JSON for client to build <option>s
            var result = cities.Select(c => new { value = c.Id, text = c.Name });
            return Json(result);
        }

        // Regular or AJAX submit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Submit(AddressViewModel model)
        {
            if (!ModelState.IsValid)
            {
                // Rebuild the lists for redisplay
                model.Countries = Countries.Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name, Selected = (model.CountryId == c.Id) });
                if (model.CountryId.HasValue && CitiesByCountry.TryGetValue(model.CountryId.Value, out var cities))
                {
                    model.Cities = cities.Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name, Selected = (model.CityId == c.Id) });
                }
                else
                {
                    model.Cities = Enumerable.Empty<SelectListItem>();
                }

                // If request expects JSON (AJAX), send errors
                if (Request.Headers["Accept"].ToString().Contains("application/json", StringComparison.OrdinalIgnoreCase))
                {
                    var errors = ModelState
                        .Where(kvp => kvp.Value!.Errors.Count > 0)
                        .ToDictionary(
                            kvp => kvp.Key,
                            kvp => kvp.Value!.Errors.Select(e => e.ErrorMessage).ToArray()
                        );
                    return BadRequest(new { message = "Validation failed.", errors });
                }

                // Non-AJAX fallback
                return View("Index", model);
            }

            // TODO: persist data here (CountryId, CityId)

            // AJAX success
            if (Request.Headers["Accept"].ToString().Contains("application/json", StringComparison.OrdinalIgnoreCase))
            {
                return Ok(new { message = "Saved successfully.", redirectUrl = Url.Action(nameof(Success)) });
            }

            // PRG for non-AJAX
            TempData["Success"] = "Saved successfully.";
            return RedirectToAction(nameof(Success));
        }

        [HttpGet]
        public IActionResult Success()
        {
            ViewBag.Message = TempData["Success"] ?? "Saved.";
            return View();
        }

    }
}
 