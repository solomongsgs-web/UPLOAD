﻿using Microsoft.EntityFrameworkCore;
using MvcCascade.Data;
using MvcCascade.Models;
using System.Diagnostics.Metrics;
using Exception = MvcCascade.Models.Exception;


namespace MvcCascade.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        { }

        public DbSet<Unit> Unit { get; set; }
        public DbSet<Exception> Exception { get; set; }
        public DbSet<Branches> Branches { get; set; }


        public DbSet<ExHeader> ExHeaders { get; set; }
        public DbSet<ExDetail> ExDetails { get; set; }

    }
}
 