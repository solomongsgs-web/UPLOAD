﻿using MvcCascade.Models;

namespace MvcCascade.ViewModels
{
    public class BranchSearchViewModel
    {
        // what the user typed
        public string? Query { get; set; }

        // choose one search mode (Id, Name, SKU, etc.)
        public string SearchBy { get; set; } = "Id"; // "Id" | "Name"

        // the found record (if any)
        public Branches? Result { get; set; }

        // UI message when not found or invalid input
        public string? Message { get; set; }

    }
}
 