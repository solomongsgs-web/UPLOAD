﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MvcCascade.Models
{
    public class Unit
    {
        public int Id { get; set; }

        [Key]
        [MaxLength(4)]
        public string Name { get; set; }

        [Required]
        [MaxLength(50)]
        public string Desc { get; set; }

 

        public ICollection<Exception> Exceptions { get; set; } = new List<Exception>();
   
    }
}