Imports System.DirectoryServices.AccountManagement

' Created by: Jefferson G. Toledo | ADSD-FRD
'NOTE: requires System.DirectoryServices.AccountManagement.dll to work

Public Class Login
    Public currentUser As String

    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        Me.UserLogin()
    End Sub

    Private Sub UserLogin()
        Dim valid As Boolean = False

        Try
            Dim user As UserPrincipal = UserPrincipal.Current

            Dim FullName As String = user.Name


            If (txtPassword.Text.Trim() <> "") AndAlso (txtUsername.Text.Trim() <> "") Then

                Using context As New PrincipalContext(ContextType.Domain)

                    valid = context.ValidateCredentials(txtUsername.Text.Trim(), txtPassword.Text.Trim())
                    currentUser = txtUsername.Text.Trim()

                    If valid = True Then
                        'MsgBox("Login successful!" & vbNewLine & "Welcome: " & user.DisplayName, vbInformation, "LDAP Login")

                        MsgBox("DistinguishedName: " & user.DistinguishedName & vbNewLine & vbNewLine & "UserPrincipalName: " & user.UserPrincipalName &
                                vbNewLine & vbNewLine & "SamAccountName: " & user.SamAccountName)

                        MsgBox("ConnectedServer: " & context.ConnectedServer & vbNewLine & "Container: " & context.Container & "Name: " & context.Name &
                               "UserName: " & vbNewLine & context.UserName)


                        Me.Hide() : End ' Call MainForm
                    Else
                        MsgBox("Invalid username/password.", MsgBoxStyle.Critical, "LDAP Login")

                        If (user.IsAccountLockedOut = True) Then
                            MessageBox.Show("Account is locked out. Please contact system administrator.")
                        End If
                    End If

                End Using
            Else
                MsgBox("Username/password cannot be empty.", MsgBoxStyle.Critical, "LDAP Login")
            End If

        Catch ex As Exception
            MsgBox("Error connecting to AD. Please check connection.", MsgBoxStyle.Critical, "LDAP Login")
        End Try
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        End
    End Sub
    Private Sub txtPassword_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtPassword.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            Me.btnGo.Focus()
        End If
    End Sub

    Private Sub txtUsername_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtUsername.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            Me.txtPassword.Focus()
        End If
    End Sub

End Class