﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MvcCascade.Models
{
    public class AddressViewModel
    {
        [Required]
        [Display(Name = "Country")]
        public int? CountryId { get; set; }

        [Required]
        [Display(Name = "City")]
        public int? CityId { get; set; }

        // Populated in the GET; used to build <option> items
        public IEnumerable<SelectListItem> Countries { get; set; } = new List<SelectListItem>();
        public IEnumerable<SelectListItem> Cities { get; set; } = new List<SelectListItem>();
    }
}
