﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace MvcCascade.Models
{
    public class ExDetail
    {
        public int Id { get; set; }

        [Required]
        public int HeaderID { get; set; }

        [Required, StringLength(12)]
        public string PKEY { get; set; } = default!;

        [Required, StringLength(10)]
        public string BRCODE { get; set; } = default!;

        [Required, StringLength(80)]
        public string EXCEPTION { get; set; }

        public int COUNT { get; set; }
     
        [Required, StringLength(100)]
        public string OTHERS { get; set; } = default!;
        [Required, StringLength(100)]
        public string REMARKS { get; set; } = default!;

        [Required, StringLength(8)]
        public string EID { get; set; } = default!;
        [Required, StringLength(20)]
        public string STATUS { get; set; } = default!;

    }
}
 

 